package com.example.calendaraplication

import android.app.Activity

class ManagePermissions(val activity: Activity,val list: List<String>,val code:Int) {


}