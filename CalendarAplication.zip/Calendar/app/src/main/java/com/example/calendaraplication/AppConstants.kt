package com.example.calendaraplication

object AppConstants {
    val TAKE_PHOTO_REQUEST: Int = 2
    val PICK_PHOTO_REQUEST: Int = 1
}